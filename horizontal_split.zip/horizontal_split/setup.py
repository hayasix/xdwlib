#!/usr/bin/env python2.6
# vim: fileencoding=utf-8

from distutils.core import setup
import py2exe

py2exe_options=dict(
    compressed=1,
    optimize=2,
    bundle_files=1,
    )

setup(
    options=dict(py2exe=py2exe_options),
    #console=[dict(script="horizontal_split.py",),],
    windows=[dict(
            script="horizontal_split.py",
            #icon_resources=[(1, "horizontal_split.ico"),],
            ),],
    zipfile=None,
    )
